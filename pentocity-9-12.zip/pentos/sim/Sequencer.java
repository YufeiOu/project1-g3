package pentos.sim;

public interface Sequencer {

    public void init();
    public Building next();

}
